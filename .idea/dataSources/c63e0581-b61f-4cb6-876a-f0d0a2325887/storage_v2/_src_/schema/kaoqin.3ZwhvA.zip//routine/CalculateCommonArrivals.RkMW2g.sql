create
    definer = root@localhost procedure CalculateCommonArrivals(IN startDate date, IN endDate date)
BEGIN
    -- 创建临时表来存储早到和晚到的员工
    CREATE TEMPORARY TABLE TempCommonArrivals AS
    SELECT e1.wno, e1.wname
    FROM (
        SELECT wno, wname FROM TempEarlyArrivals
    ) AS e1
    JOIN (
        SELECT wno, wname FROM TempLaterArrivals
    ) AS e2
    ON e1.wno = e2.wno;

    -- 返回结果
    SELECT * FROM TempCommonArrivals;

    -- 删除临时表
    DROP TEMPORARY TABLE IF EXISTS TempCommonArrivals;
    DROP TEMPORARY TABLE IF EXISTS TempEarlyArrivals;
    DROP TEMPORARY TABLE IF EXISTS TempLaterArrivals;
END;

