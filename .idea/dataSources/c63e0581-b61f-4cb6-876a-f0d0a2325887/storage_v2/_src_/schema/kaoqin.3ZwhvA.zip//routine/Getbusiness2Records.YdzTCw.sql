create
    definer = root@localhost procedure Getbusiness2Records(IN start_date date, IN end_date date)
BEGIN
    SELECT * FROM out_business_info
    WHERE DATE(bitime) BETWEEN start_date AND end_date
    AND bistate = '回岗';
END;

