create definer = root@localhost trigger check_ask_for_leave_info
    after insert
    on ask_for_leave_info
    for each row
BEGIN
    DECLARE count_leave_records INT;
    SELECT COUNT(*) INTO count_leave_records
    FROM ask_for_leave_info
    WHERE wno = NEW.wno AND listate = '请假';
    
    IF count_leave_records = 0 THEN
        -- 执行相关操作，例如阻止插入销假记录或抛出错误
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '无有效的请假记录，无法插入销假记录';
    END IF;
END;

