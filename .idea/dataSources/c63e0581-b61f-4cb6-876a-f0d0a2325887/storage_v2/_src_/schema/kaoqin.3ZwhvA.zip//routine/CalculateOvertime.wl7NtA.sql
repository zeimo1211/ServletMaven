create
    definer = root@localhost procedure CalculateOvertime(IN startDate date, IN endDate date)
BEGIN
    -- 创建临时表来存储符合条件的员工

    CREATE TEMPORARY TABLE TempOvertime AS
    SELECT w.wno, w.wname, 
		   DATE(wi.witime) AS work_date,
		   TIMEDIFF(TIME(wi.witime), d.dofftime) AS overtime_duration
    FROM worker w
    JOIN department_worker dw ON w.wno = dw.wno
    JOIN department d ON dw.dno = d.dno
    LEFT JOIN work_info wi ON w.wno = wi.wno
        AND DATE(wi.witime) BETWEEN startDate AND endDate
    WHERE d.dofftime IS NOT NULL AND wi.wistate = '下班' AND TIME(wi.witime) > d.dofftime;

    -- 返回结果，计算加班时长
    SELECT wno, wname, work_date,overtime_duration
    FROM TempOvertime;

    -- 删除临时表
    DROP TEMPORARY TABLE IF EXISTS TempOvertime;

END;

