create
    definer = root@localhost procedure CalculateArrivals(IN startDate date, IN endDate date)
BEGIN
    -- 创建临时表来存储符合条件的员工
    CREATE TEMPORARY TABLE TempEarlyArrivals AS
    SELECT w.wno, w.wname
    FROM worker w
    JOIN department_worker dw ON w.wno = dw.wno
    JOIN department d ON dw.dno = d.dno
    LEFT JOIN work_info wi ON w.wno = wi.wno
        AND DATE(wi.witime) BETWEEN startDate AND endDate
    WHERE d.dontime IS NOT NULL AND wi.wistate = '上班' AND TIME(wi.witime) < d.dontime
    GROUP BY w.wno, w.wname
    HAVING COUNT(w.wno) = DATEDIFF(endDate, startDate) + 1;
    
    CREATE TEMPORARY TABLE TempLaterArrivals AS
    SELECT w.wno, w.wname
    FROM worker w
    JOIN department_worker dw ON w.wno = dw.wno
    JOIN department d ON dw.dno = d.dno
    LEFT JOIN work_info wi ON w.wno = wi.wno
        AND DATE(wi.witime) BETWEEN startDate AND endDate
    WHERE d.dofftime IS NOT NULL AND wi.wistate = '下班' AND TIME(wi.witime) > d.dofftime
    
    GROUP BY w.wno, w.wname
    HAVING COUNT(w.wno) = DATEDIFF(endDate, startDate) + 1;
    
    -- 返回结果
    SELECT tea.wno, tla.wname
	FROM TempEarlyArrivals tea
			 JOIN TempLaterArrivals tla ON tea.wno=tla.wno;
    -- 删除临时表
    DROP TEMPORARY TABLE IF EXISTS TempEarlyArrivals;
    DROP TEMPORARY TABLE IF EXISTS TempLaterArrivals;
    
END;

