create
    definer = root@localhost procedure GetLeaveRecords(IN start_date date, IN end_date date)
BEGIN
    SELECT * FROM ask_for_leave_info
    WHERE DATE(litime) BETWEEN start_date AND end_date
    AND listate = '请假';
END;

