create
    definer = root@localhost procedure GetbusinessRecords(IN start_date date, IN end_date date)
BEGIN
    SELECT * FROM out_business_info
    WHERE DATE(bitime) BETWEEN start_date AND end_date
    AND bistate = '出差';
END;

