create
    definer = root@localhost procedure GetLeave2Records(IN start_date date, IN end_date date)
BEGIN
    SELECT * FROM ask_for_leave_info
    WHERE DATE(litime) BETWEEN start_date AND end_date
    AND listate = '销假';
END;

