create
    definer = root@localhost procedure insert_sale_info(IN sale_id int, IN oil_id int, IN depot_id int, IN staff_id int,
                                                        IN quantity int, IN member_id int)
BEGIN
    DECLARE sale_time DATETIME;
    DECLARE discount DECIMAL(4,2);
    DECLARE oil_price DECIMAL(10,2);

    -- 设置时间为当前时间
    SET sale_time = NOW();

    -- 查询折扣
    SELECT discount INTO discount
    FROM member_info
    WHERE member_id = member_id
    LIMIT 1;
	-- 在查询折扣之后添加条件判断
	IF discount IS NULL THEN
		-- 折扣为空，执行错误处理逻辑，例如设置一个默认值
		SET discount = 0.00; -- 设置默认折扣为0.00
		-- 或者抛出错误
		-- SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid discount';
	END IF;

    -- 查询油品价格
    SELECT price INTO oil_price
    FROM oil_type
    WHERE oil_id = oil_id
    LIMIT 1;

    -- 检查油品价格是否有效
    IF oil_price IS NOT NULL THEN
        -- 插入数据到销售表
        INSERT INTO sale_info (sale_id, sale_time, oil_id, depot_id, quantity, price, staff_id, member_id, discount)
        VALUES (sale_id, sale_time, oil_id, depot_id, quantity, oil_price, staff_id, member_id, discount);
    ELSE
        -- 油品价格无效，抛出错误或执行其他错误处理操作
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid oil price';
    END IF;
END;

