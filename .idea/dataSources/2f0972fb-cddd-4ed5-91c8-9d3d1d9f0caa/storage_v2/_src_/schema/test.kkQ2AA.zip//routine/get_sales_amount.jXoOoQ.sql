create
    definer = root@localhost function get_sales_amount(employee_id int, date varchar(7)) returns decimal(10, 2)
    deterministic
BEGIN
    DECLARE sales DECIMAL(10, 2);
    
    SELECT SUM(quantity * price) INTO sales
    FROM sale_info
    WHERE staff_id = employee_id
        AND DATE_FORMAT(sale_time, '%Y-%m') = date;
    
    IF sales IS NULL THEN
        SET sales = 0;
    END IF;
    
    RETURN sales;
END;

