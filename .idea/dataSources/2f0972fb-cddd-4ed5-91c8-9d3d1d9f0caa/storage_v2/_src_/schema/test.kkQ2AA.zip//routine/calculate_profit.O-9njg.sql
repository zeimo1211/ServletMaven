create
    definer = root@localhost procedure calculate_profit(IN p_year int)
BEGIN
    DECLARE v_oil_id INT;
    DECLARE v_depot_id INT;
    DECLARE v_quantity INT;
    DECLARE v_price DECIMAL(10,2);
    DECLARE v_profit DECIMAL(10,2);
    
    -- 创建临时表用于存储各个油库的利润
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_profit (
        depot_id INT,
        profit DECIMAL(10,2)
    );
    
    -- 清空临时表
    TRUNCATE TABLE temp_profit;
    
    -- 获取销售信息中符合指定年份的记录，并计算利润
    INSERT INTO temp_profit (depot_id, profit)
    SELECT si.depot_id, SUM(si.price * si.quantity)
    FROM sale_info si
    WHERE YEAR(si.sale_time) = p_year
    GROUP BY si.depot_id;
    
    -- 查询油库信息，并显示利润
    SELECT od.name AS depot_name, tp.profit
    FROM oil_depot od
    LEFT JOIN temp_profit tp ON od.depot_id = tp.depot_id;
    
    -- 删除临时表
    DROP TEMPORARY TABLE IF EXISTS temp_profit;
    
END;

