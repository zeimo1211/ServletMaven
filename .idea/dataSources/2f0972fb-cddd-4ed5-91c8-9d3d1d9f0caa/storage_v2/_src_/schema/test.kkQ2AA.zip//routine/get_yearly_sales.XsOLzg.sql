create
    definer = root@localhost function get_yearly_sales(oil_id int) returns int
BEGIN
    DECLARE sales INT;
    
    SET sales = (
        SELECT SUM(quantity)
        FROM sale_info
        WHERE oil_id = oil_id
            AND YEAR(sale_time) = YEAR(CURRENT_DATE())
    );
    
    IF sales IS NULL THEN
        SET sales = 0;
    END IF;
    
    RETURN sales;
END;

