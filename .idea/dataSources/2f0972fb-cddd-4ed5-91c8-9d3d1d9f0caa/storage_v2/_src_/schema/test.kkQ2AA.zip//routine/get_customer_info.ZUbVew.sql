create
    definer = root@localhost procedure get_customer_info()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE customer_id INT;
    DECLARE customer_name VARCHAR(50);
    DECLARE customer_level VARCHAR(50);
    DECLARE customer_total_consume DECIMAL(10, 2);
    
    -- 创建游标
    DECLARE customer_cursor CURSOR FOR
        SELECT mi.member_id, mi.name, ml.level_name, mi.total_consume
        FROM member_info mi
        INNER JOIN member_level ml ON mi.level_id = ml.level_id;
    
    -- 声明异常处理程序
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
	-- 创建结果集表
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_customer_info (
        customer_id INT,
        customer_name VARCHAR(50),
        customer_level VARCHAR(50),
        customer_total_consume DECIMAL(10, 2)
    );
    
    -- 打开游标
    OPEN customer_cursor;
    
    -- 读取游标数据
    read_loop: LOOP
        -- 从游标中获取数据
        FETCH NEXT FROM customer_cursor INTO customer_id, customer_name, customer_level, customer_total_consume;
        
        -- 检查是否已读取完所有数据
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- 插入数据到结果集表
        INSERT INTO temp_customer_info (customer_id, customer_name, customer_level, customer_total_consume)
        VALUES (customer_id, customer_name, customer_level, customer_total_consume);
    END LOOP;
    
    -- 关闭游标
    CLOSE customer_cursor;
    
    -- 返回结果集
    SELECT * FROM temp_customer_info;
    
    -- 清除结果集表
    DROP TABLE IF EXISTS temp_customer_info;
    
END;

